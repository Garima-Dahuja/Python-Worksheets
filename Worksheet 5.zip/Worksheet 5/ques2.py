import numpy as np
from scipy.fftpack import fft

# Generate a 2D NumPy array
arr_2d = np.random.random((4, 4))

# Perform Discrete Fourier Transform
fft_result = fft(arr_2d)

print(fft_result)
