import numpy as np
from scipy import linalg

# Create a 3x3 matrix
matrix = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])

# Determinant
det = linalg.det(matrix)

# Inverse
try:
    inv = linalg.inv(matrix)
except np.linalg.LinAlgError:
    inv = "Matrix is singular, no inverse."

# Eigenvalues
eigvals, eigvecs = linalg.eig(matrix)

print(f"Determinant: {det}")
print(f"Inverse: {inv}")
print(f"Eigenvalues: {eigvals}")
