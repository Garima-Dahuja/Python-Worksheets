def get_distinct_elements():
    lst = input("Enter elements of the list separated by spaces: ").split()
    # lst = [int(x) for x in lst]
    return list(set(lst))


result = get_distinct_elements()
print(f"Distinct elements: {result}")