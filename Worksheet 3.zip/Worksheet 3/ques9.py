class Student:
    def __init__(self, student_id, student_name, student_class):
        self.student_id = student_id
        self.student_name = student_name
        self.student_class = student_class

    def display(self):
        print(f"ID: {self.student_id}, Name: {self.student_name}, Class: {self.student_class}")

def create_student():
    student_id = input("Enter student ID: ")
    student_name = input("Enter student name: ")
    student_class = input("Enter student class: ")
    student = Student(student_id, student_name, student_class)
    student.display()


create_student()
