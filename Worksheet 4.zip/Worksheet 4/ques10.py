import numpy as np

# 1. Create the matrix A
A = np.array([[2, 1, 3],
              [0, 5, 6],
              [7, 8, 9]])

# 2. Find the determinant of matrix A
det_A = np.linalg.det(A)
print("Determinant of A:", det_A)

# 3. Compute the inverse of matrix A
if det_A != 0:
    inv_A = np.linalg.inv(A)
    print("Inverse of A:\n", inv_A)
else:
    print("Matrix A is singular and does not have an inverse.")

# 4. Find the eigenvalues and eigenvectors of matrix A
eigenvalues, eigenvectors = np.linalg.eig(A)
print("Eigenvalues of A:", eigenvalues)
print("Eigenvectors of A:\n", eigenvectors)
