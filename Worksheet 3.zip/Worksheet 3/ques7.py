def outer_function():
    def inner_function():
        print("Inner function called")
    inner_function()


outer_function()