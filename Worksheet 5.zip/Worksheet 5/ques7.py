import numpy as np

# Data for students' marks in multiple subjects
data = {
    'Arin': [85, 78, 92, 88],
    'Aditya': [79, 82, 74, 90],
    'Chirag': [90, 85, 89, 92],
    'Gurleen': [66, 75, 80, 78],
    'Kunal': [70, 68, 75, 85]
}

# Convert to NumPy array
marks = np.array(list(data.values()))
print(marks)

# Total marks for each student
total_marks = np.sum(marks, axis=1)

# Average marks for each subject
avg_marks_subject = np.mean(marks, axis=0)

# Top and bottom performers
top_performer = np.argmax(total_marks)
bottom_performer = np.argmin(total_marks)

print(f"Total marks for each student: {total_marks}")
print(f"Average marks for each subject: {avg_marks_subject}")
print(f"Top performer: {list(data.keys())[top_performer]}")
print(f"Bottom performer: {list(data.keys())[bottom_performer]}")

