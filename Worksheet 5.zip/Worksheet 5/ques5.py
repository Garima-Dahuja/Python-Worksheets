import numpy as np
from scipy import signal
import matplotlib.pyplot as plt

# Generate a time series dataset
t = np.linspace(0, 1, 500)
noisy_signal = np.sin(2 * np.pi * 7 * t) + np.random.randn(500) * 0.5

# Apply a low-pass filter using SciPy's signal processing
sos = signal.butter(10, 15, 'lp', fs=500, output='sos')
filtered_signal = signal.sosfilt(sos, noisy_signal)

# Plot the original and filtered signals
plt.plot(t, noisy_signal, label='Noisy Signal')
plt.plot(t, filtered_signal, label='Filtered Signal')
plt.legend()
plt.show()
