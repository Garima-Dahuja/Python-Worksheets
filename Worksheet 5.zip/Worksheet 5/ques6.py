import numpy as np

# Simulate sales data (12 months, 4 products)
sales_data = np.random.randint(100, 1000, (12, 4))

# Total sales for each product
total_sales = np.sum(sales_data, axis=0)

# Average sales per month
avg_sales = np.mean(sales_data, axis=0)

# Maximum and minimum sales
max_sales = np.max(sales_data, axis=0)
min_sales = np.min(sales_data, axis=0)

# Best and worst performing month
best_month = np.argmax(np.sum(sales_data, axis=1)) + 1
worst_month = np.argmin(np.sum(sales_data, axis=1)) + 1

print(f"Total sales: {total_sales}")
print(f"Average sales: {avg_sales}")
print(f"Best performing month: {best_month}")
print(f"Worst performing month: {worst_month}")
