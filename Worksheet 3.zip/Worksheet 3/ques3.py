def reverse_string():
    s = input("Enter a string: ")
    return s[::-1]


result = reverse_string()
print(f"Reversed string: {result}")