import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

# Time and velocity data
time = np.array([0, 1, 2, 3, 4, 5])
velocity = np.array([2, 3.1, 7.9, 18.2, 34.3, 56.2])

# Define the quadratic function for fitting
def func(t, a, b, c):
    return a * t**2 + b * t + c

# Curve fitting
params, covariance = curve_fit(func, time, velocity)

# Generate fitted velocity
fitted_velocity = func(time, *params)

# Plot the original data and fitted curve
plt.plot(time, velocity, 'o', label='Original Data')
plt.plot(time, fitted_velocity, '-', label='Fitted Curve')
plt.legend()
plt.show()
