import numpy as np
from scipy import interpolate
import matplotlib.pyplot as plt

# Generate some data points
x = np.linspace(0, 10, 10)
y = np.sin(x)

# Perform interpolation
f = interpolate.interp1d(x, y, kind='cubic')

# Generate new data points for interpolation
x_new = np.linspace(0, 10, 100)
y_new = f(x_new)

# Plot the original and interpolated data
plt.plot(x, y, 'o', label='Original Data')
plt.plot(x_new, y_new, '-', label='Interpolated Data')
plt.legend()
plt.show()
