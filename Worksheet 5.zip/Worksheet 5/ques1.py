import numpy as np
from scipy import stats

# Create a NumPy array of random numbers
random_array = np.random.rand(100)  # 100 random numbers between 0 and 1

# Calculate the statistical properties using SciPy
mean = stats.tmean(random_array)
median = stats.scoreatpercentile(random_array, 50)  # SciPy doesn't have a direct median function, using percentile
variance = stats.tvar(random_array)

# Display the results
print(f"Mean: {mean}")
print(f"Median: {median}")
print(f"Variance: {variance}")
