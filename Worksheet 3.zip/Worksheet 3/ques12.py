class StringManipulation:
    def get_String(self):
        self.s = input("Enter a string: ")

    def print_String(self):
        print(self.s.upper())

def string_manipulation():
    obj = StringManipulation()
    obj.get_String()
    obj.print_String()


string_manipulation()
# class Stringmanipulation:
#     def __init__(self,s):
#         self.s=s
#     def up(self):
#         print(self.s.upper())
     
# def input():
#     st=input("Enter the string: ")
#     new=Stringmanipulation(st)
#     new.up()
#     # new.display()

# input()
