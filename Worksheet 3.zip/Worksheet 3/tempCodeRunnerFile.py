a.reshape(3,3,11)
# print(a)