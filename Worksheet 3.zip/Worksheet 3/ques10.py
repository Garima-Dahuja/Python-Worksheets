class Student:
    def __init__(self, student_id, student_name):
        self.student_id = student_id
        self.student_name = student_name

    def display(self):
        print(f"ID: {self.student_id}, Name: {self.student_name}")

def create_students():
    student1_id = input("Enter first student's ID: ")
    student1_name = input("Enter first student's name: ")
    student2_id = input("Enter second student's ID: ")
    student2_name = input("Enter second student's name: ")

    student1 = Student(student1_id, student1_name)
    student2 = Student(student2_id, student2_name)

    student1.display()
    student2.display()


create_students()